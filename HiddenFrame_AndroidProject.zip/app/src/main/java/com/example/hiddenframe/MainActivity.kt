package com.example.hiddenframe

import android.app.Activity
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts.OpenMultipleDocuments
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.*
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlin.random.Random
import androidx.room.*
import java.util.concurrent.Executors

@Entity(tableName = "vault_items")
data class VaultItem(
    @PrimaryKey val id: String,
    val displayName: String,
    val mime: String,
    val encryptedPath: String,
    val ivHex: String,
    val thumbnailPath: String?,
    val createdAt: Long
)

@Dao
interface VaultDao {
    @Query("SELECT * FROM vault_items ORDER BY createdAt DESC")
    suspend fun all(): List<VaultItem>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: VaultItem)
}

@Database(entities = [VaultItem::class], version = 1)
abstract class VaultDatabase : RoomDatabase() {
    abstract fun vaultDao(): VaultDao

    companion object {
        @Volatile private var instance: VaultDatabase? = null
        fun get(context: Context): VaultDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                VaultDatabase::class.java,
                "hidden_frame_db"
            ).setQueryExecutor(Executors.newSingleThreadExecutor()).build().also { instance = it }
        }
    }
}

object CryptoHelper {
    private const val AES_KEY_SIZE = 256
    fun generateAesKeyIfNeeded(context: Context) {
        val prefs = context.getSharedPreferences("hidden_frame_prefs", Context.MODE_PRIVATE)
        if (prefs.contains("wrapped_master")) return
        val key = ByteArray(AES_KEY_SIZE / 8)
        Random.nextBytes(key)
        prefs.edit().putString("wrapped_master", android.util.Base64.encodeToString(key, android.util.Base64.NO_WRAP)).apply()
    }

    private fun getAesKey(context: Context): SecretKey {
        val prefs = context.getSharedPreferences("hidden_frame_prefs", Context.MODE_PRIVATE)
        val base64 = prefs.getString("wrapped_master", null)
        require(base64 != null) { "Master key not generated" }
        val bytes = android.util.Base64.decode(base64, android.util.Base64.NO_WRAP)
        return SecretKeySpec(bytes, "AES")
    }

    fun encryptStreamToFile(context: Context, input: InputStream, outFile: File): String {
        val aesKey = getAesKey(context)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val iv = ByteArray(12)
        Random.nextBytes(iv)
        val gcm = GCMParameterSpec(128, iv)
        cipher.init(Cipher.ENCRYPT_MODE, aesKey, gcm)

        FileOutputStream(outFile).use { fos ->
            fos.write(iv)
            CipherOutputStream(fos, cipher).use { cos ->
                input.copyTo(cos)
            }
        }
        return iv.toHex()
    }

    fun getDecryptedInputStream(context: Context, encryptedFile: File): InputStream {
        val aesKey = getAesKey(context)
        val fis = FileInputStream(encryptedFile)
        val iv = ByteArray(12)
        val read = fis.read(iv)
        if (read != iv.size) throw IOException("Couldn't read IV")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, aesKey, GCMParameterSpec(128, iv))
        return CipherInputStream(fis, cipher)
    }
}

class VaultRepository(private val context: Context) {
    private val dao = VaultDatabase.get(context).vaultDao()

    suspend fun importUri(uri: Uri): VaultItem {
        val cr = context.contentResolver
        val meta = queryDisplayNameAndMime(cr, uri)
        val id = java.util.UUID.randomUUID().toString()
        val encryptedFile = File(context.filesDir, "$id.enc")
        cr.openInputStream(uri)!!.use { input ->
            val ivHex = CryptoHelper.encryptStreamToFile(context, input, encryptedFile)
            val item = VaultItem(id, meta.first, meta.second ?: "application/octet-stream", encryptedFile.absolutePath, ivHex, null, System.currentTimeMillis())
            dao.insert(item)
            return item
        }
    }

    suspend fun allItems(): List<VaultItem> = dao.all()

    suspend fun getDecryptedInputStream(item: VaultItem): InputStream {
        return CryptoHelper.getDecryptedInputStream(context, File(item.encryptedPath))
    }

    private fun queryDisplayNameAndMime(cr: ContentResolver, uri: Uri): Pair<String, String?> {
        var name = "file"
        var mime = cr.getType(uri)
        cr.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) name = c.getString(idx)
            }
        }
        return Pair(name, mime)
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CryptoHelper.generateAesKeyIfNeeded(this)

        // require biometric before showing vault
        if (!checkBiometric()) {
            Toast.makeText(this, "No biometric available - continuing without biometric.", Toast.LENGTH_SHORT).show()
            setContentViewCompat()
        } else {
            promptBiometricAndLaunch()
        }
    }

    private fun checkBiometric(): Boolean {
        val bm = BiometricManager.from(this)
        return bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
    }

    private fun promptBiometricAndLaunch() {
        val executor = java.util.concurrent.Executors.newSingleThreadExecutor()
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                runOnUiThread { setContentViewCompat() }
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Authentication error: $errString", Toast.LENGTH_SHORT).show()
                    setContentViewCompat()
                }
            }
            override fun onAuthenticationFailed() {
                // stay on prompt
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock Hidden Frame")
            .setSubtitle("Use your fingerprint or device credential to unlock")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
            .build()
        prompt.authenticate(info)
    }

    private fun setContentViewCompat() {
        setContent {
            HiddenFrameTheme {
                val repo = remember { VaultRepository(this) }
                val itemsState = remember { mutableStateListOf<VaultItem>() }
                val scope = rememberCoroutineScope()

                LaunchedEffect(Unit) {
                    scope.launch {
                        val list = withContext(Dispatchers.IO) { repo.allItems() }
                        itemsState.clear(); itemsState.addAll(list)
                    }
                }

                val pickLauncher = rememberLauncherForActivityResult(OpenMultipleDocuments()) { uris ->
                    if (uris != null && uris.isNotEmpty()) {
                        scope.launch {
                            for (u in uris) {
                                try {
                                    val imported = withContext(Dispatchers.IO) { repo.importUri(u) }
                                    itemsState.add(0, imported)
                                } catch (e: Exception) {
                                    Log.e("HiddenFrame", "Import failed", e)
                                }
                            }
                        }
                    }
                }

                Scaffold(
                    topBar = {
                        TopAppBar(
                            backgroundColor = Color(0xFF0D1321),
                            title = {
                                Text("Hidden Frame", color = Color(0xFF00D4A2), fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            }
                        )
                    },
                    floatingActionButton = {
                        FloatingActionButton(
                            onClick = { pickLauncher.launch(arrayOf("image/*", "video/*")) },
                            backgroundColor = Color(0xFF00D4A2)
                        ) {
                            Text("+", color = Color.White, fontSize = 24.sp)
                        }
                    }
                ) { padding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color(0xFF0D1321), Color(0xFF1E293B))
                                )
                            )
                            .padding(padding)
                    ) {
                        if (itemsState.isEmpty()) {
                            Text(
                                text = "Your hidden gallery is empty. Tap + to import.",
                                color = Color.LightGray,
                                modifier = Modifier.align(Alignment.Center)
                            )
                        } else {
                            LazyVerticalGrid(columns = GridCells.Fixed(3), contentPadding = PaddingValues(8.dp)) {
                                items(itemsState) { item ->
                                    Card(
                                        modifier = Modifier
                                            .padding(4.dp)
                                            .height(120.dp)
                                            .clickable { scope.launch { openViewer(this@MainActivity, repo, item) } },
                                        shape = RoundedCornerShape(12.dp),
                                        backgroundColor = Color(0xFF1E293B)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(item.displayName.take(10), color = Color.White, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private suspend fun openViewer(activity: Activity, repo: VaultRepository, item: VaultItem) {
        withContext(Dispatchers.IO) {
            val ins = repo.getDecryptedInputStream(item)
            val tmp = File(activity.cacheDir, "tmp_${item.id}")
            FileOutputStream(tmp).use { fos -> ins.copyTo(fos) }
            withContext(Dispatchers.Main) {
                try {
                    val uri = FileProvider.getUriForFile(activity, activity.packageName + ".fileprovider", tmp)
                    val intent = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, item.mime)
                        flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                    }
                    startActivity(intent)
                } catch (e: Exception) {
                    Toast.makeText(activity, "Cannot open file: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            tmp.delete()
        }
    }
}

@Composable
fun HiddenFrameTheme(content: @Composable () -> Unit) {
    MaterialTheme(colors = darkColors(primary = Color(0xFF00D4A2), background = Color(0xFF0D1321))) {
        content()
    }
}

fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }
